﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace decimale_puntato
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int ip;
            int intero;
            int[] dp=new int[4];
            string[] decimale= new string[3];
            bool[]bin;
            Console.WriteLine("inserisci ip");
            for(int i = 0;i<4;i++)
            {
                Console.WriteLine($"{i + 1}° numero");
                dp[i] = Convert.ToInt32(Console.ReadLine());
                
            }
            bin = ConvertDpToBin(dp);
            for(int i = 0; i < bin.Length; i++)
            {
                if (bin[i] == true)
                {
                    Console.Write("1");
                }
                else
                {
                    Console.Write("0");
                }
            }
            Console.WriteLine("");
            
            intero= ConvertDpToIntero(dp);
            Console.WriteLine(intero);
            
        }
        static bool[] ConvertDpToBin(int[] dp)
        {
            int resto;
            bool[] b= new bool[32];
            int a = 32;
            for(int x=4; x<1;x++)
            {
                int numero = dp[x-1];
                for (int i = 0; i < 8; i++)
                {
                    resto = numero%2;
                    numero = (numero - resto) / 2;
                    if (resto == 1)
                    {
                        b[a] = true;
                    }
                    else
                    {
                        b[a]= false;
                    }
                    a--;
                }
            }
            return b;
        }
        static int ConvertDpToIntero(int[] dp)
        {
            int numero = 0;
            for (int i = 4;i < 0;i++)
            {
                int x = i - 1;
                
                numero=numero+(dp[x] * (int)Math.Pow(256,x));

            }
            return numero;
        }
    }
}
